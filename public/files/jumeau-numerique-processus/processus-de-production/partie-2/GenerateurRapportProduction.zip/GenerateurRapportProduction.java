package mecaprecision;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Application de génération de rapports de production de MécaPrécision.
 * Utilisée depuis un connecteur Groovy de Bonita (Partie II du TP).
 */
public class GenerateurRapportProduction {

    private static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }

    /**
     * Génère un rapport HTML et retourne le chemin du fichier créé.
     */
    public static String generer(String numeroCommande, String nomProduit, String categorie,
                                 Integer quantite, String dateProduction, String tempsCycleRetenu,
                                 String observations, String dossierSortie) throws IOException {
        File dossier = new File(dossierSortie == null || dossierSortie.isEmpty() ? "rapports" : dossierSortie);
        if (!dossier.exists() && !dossier.mkdirs()) {
            throw new IOException("Impossible de creer le dossier " + dossier.getAbsolutePath());
        }
        String nomFichier = "rapport_production_" + (numeroCommande == null ? "sans_numero" : numeroCommande.replaceAll("[^A-Za-z0-9_-]", "_")) + ".html";
        File fichier = new File(dossier, nomFichier);
        String horodatage = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));
        StringBuilder sb = new StringBuilder();
        sb.append("<!DOCTYPE html>\n<html lang=\"fr\"><head><meta charset=\"UTF-8\"><title>Rapport de production</title>\n");
        sb.append("<style>body{font-family:Arial,sans-serif;margin:40px;color:#222}h1{color:#0E3A5B}")
          .append("table{border-collapse:collapse;min-width:480px}td,th{border:1px solid #ccc;padding:8px 14px;text-align:left}")
          .append("th{background:#E8EEF3;width:220px}</style></head><body>\n");
        sb.append("<h1>Rapport de production - MécaPrécision</h1>\n");
        sb.append("<p>Généré le ").append(horodatage).append("</p>\n<table>\n");
        ligne(sb, "Numéro de commande", numeroCommande);
        ligne(sb, "Produit", nomProduit);
        ligne(sb, "Catégorie", categorie);
        ligne(sb, "Quantité produite", quantite == null ? "" : String.valueOf(quantite));
        ligne(sb, "Date de production", dateProduction);
        ligne(sb, "Temps de cycle retenu (h)", tempsCycleRetenu);
        ligne(sb, "Observations du contrôle qualité", observations);
        sb.append("</table>\n</body></html>\n");
        Files.write(fichier.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
        return fichier.getAbsolutePath();
    }

    private static void ligne(StringBuilder sb, String label, String valeur) {
        sb.append("<tr><th>").append(esc(label)).append("</th><td>").append(esc(valeur)).append("</td></tr>\n");
    }

    public static void main(String[] args) throws IOException {
        String chemin = generer("CMD-001", "Axe usiné", "A", 120, "2026-11-20", "6-8", "Production conforme", "rapports");
        System.out.println("Rapport généré : " + chemin);
    }
}
