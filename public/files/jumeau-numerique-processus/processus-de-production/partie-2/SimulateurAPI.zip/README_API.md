# Simulateur d'API de l'atelier MécaPrécision (Partie II)

Le simulateur joue le rôle de l'atelier : il répond aux appels REST du processus Bonita. Il existe en deux versions identiques, à lancer au choix.

## Lancement

### Méthode 1 : Node.js (si Node.js est installé)

Vérifier : `node -v` (Node.js 16 ou plus).

```
node api-simulator.js
```

Node.js portable (sans droits administrateur) : décompresser l'archive zip de Node.js dans un dossier, puis

```
"C:\chemin\node-portable\node.exe" api-simulator.js
```

### Méthode 2 : Java (sans rien installer)

Bonita Studio contient son propre Java. Si la commande `java` n'est pas reconnue, utiliser celui de Studio (dossier `jre\bin` ou `jdk\bin` dans le dossier d'installation de Bonita Studio) :

```
java -jar api-simulator.jar
"C:\chemin\BonitaStudio\jre\bin\java.exe" -jar api-simulator.jar
```

Vérifier : `java -version` (Java 11 ou plus).

### Dans les deux cas

- Se placer dans le dossier qui contient le fichier avant de taper la commande (cd).
- Le nom du fichier ne contient ni espace ni majuscule : `api-simulator.js` ou `api-simulator.jar`.
- Le terminal affiche `Simulateur atelier sur http://localhost:3000`. Laisser la fenêtre ouverte pendant le TP (Ctrl+C pour arrêter).
- Test : ouvrir `http://localhost:3000/api/machines/M-01/etat` dans un navigateur.
- Changer de port : variable d'environnement PORT (ex. `set PORT=3001` sous Windows avant la commande).
- Si le port 3000 est déjà utilisé, le simulateur s'arrête avec une erreur : fermer l'autre programme ou changer de port.

## Routes

| Route | Rôle |
|---|---|
| `GET /api/machines/{id}/etat` | État d'un poste (M-01, M-02, M-03, M-04) : statut, température, vibration, cadence |
| `GET /api/qualite/{categorie}` | Taux de défauts par catégorie (A, B, C, D) et seuil |
| `POST /api/ordres-production` | Envoie un ordre de production (JSON : numeroCommande, machine, quantite, ...) |
| `GET /api/ordres-production` | Liste des ordres reçus (pour vérifier) |

Machines : M-01 et M-02 en marche, M-03 en alerte, M-04 à l'arrêt (ordre refusé).

## Sécurité

Le `POST /api/ordres-production` exige l'en-tête `X-API-Key: tp-mecaprecision-2026` (modifiable avec la variable d'environnement `API_KEY`). Réponses :

- `401` : clé absente ou invalide ;
- `400` : JSON invalide ou champs manquants ;
- `422` : quantité qui n'est pas un entier entre 1 et 10000 ;
- `404` : machine inconnue ;
- `409` : machine à l'arrêt ;
- `201` : ordre accepté (retourne `idOrdre`).

Les `GET` restent ouverts. Ceci illustre l'authentification et la validation des données ; un vrai système ajouterait HTTPS, des clés par client et une journalisation.

## Exemples

Voir `exemples-api.json`.
