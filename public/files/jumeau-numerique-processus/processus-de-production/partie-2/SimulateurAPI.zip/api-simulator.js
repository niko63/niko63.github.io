// api-simulator.js - Simulateur d'API de l'atelier MécaPrécision (Partie II du TP)
// Aucun module externe : node api-simulator.js  (Node.js 16+)
// GET  /api/machines/:id/etat          -> état d'un poste (capteurs simulés)
// GET  /api/qualite/:categorie         -> taux de défauts par catégorie A, B, C, D
// POST /api/ordres-production          -> envoi d'un ordre de production à un poste
// GET  /api/ordres-production          -> liste des ordres reçus (pour vérifier)
// Sécurité : le POST exige l'en-tête X-API-Key (clé de TP ci-dessous) et valide les données.
const http = require('http');
const PORT = process.env.PORT || 3000;

const machines = {
  'M-01': { temperature: 62, vibration: 2.1, cadence: 110, statut: 'EN_MARCHE' },
  'M-02': { temperature: 58, vibration: 1.8, cadence: 95, statut: 'EN_MARCHE' },
  'M-03': { temperature: 81, vibration: 4.6, cadence: 70, statut: 'ALERTE' },
  'M-04': { temperature: 24, vibration: 0.0, cadence: 0, statut: 'ARRET' }
};
const defauts = { A: 0.8, B: 1.5, C: 2.7, D: 4.2 };
const API_KEY = process.env.API_KEY || 'tp-mecaprecision-2026';
const ordres = [];
let compteur = 1;

const noise = (v, a) => Math.round((v + (Math.random() * 2 - 1) * a) * 10) / 10;

function send(res, code, body) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(body));
}

const server = http.createServer((req, res) => {
  res.on('finish', () => console.log(new Date().toLocaleTimeString() + '  ' + req.method + ' ' + req.url + '  ->  ' + res.statusCode));
  const url = new URL(req.url, 'http://localhost');
  const parts = url.pathname.split('/').filter(Boolean);
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, X-API-Key', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' });
    return res.end();
  }
  if (req.method === 'GET' && parts[0] === 'api' && parts[1] === 'machines' && parts[3] === 'etat') {
    const id = parts[2].toUpperCase();
    const m = machines[id];
    if (!m) return send(res, 404, { erreur: 'Machine inconnue : ' + id });
    const actif = m.statut !== 'ARRET';
    return send(res, 200, {
      machine: id, statut: m.statut,
      temperature: actif ? noise(m.temperature, 1.5) : m.temperature,
      vibration: actif ? noise(m.vibration, 0.2) : 0,
      cadence: actif ? Math.round(noise(m.cadence, 3)) : 0,
      horodatage: new Date().toISOString()
    });
  }
  if (req.method === 'GET' && parts[0] === 'api' && parts[1] === 'qualite' && parts[2]) {
    const c = parts[2].toUpperCase();
    if (!(c in defauts)) return send(res, 404, { erreur: 'Catégorie inconnue : ' + c });
    return send(res, 200, { categorie: c, tauxDefauts: noise(defauts[c], 0.2), seuil: 3.0, horodatage: new Date().toISOString() });
  }
  if (parts[0] === 'api' && parts[1] === 'ordres-production') {
    if (req.method === 'GET') return send(res, 200, ordres);
    if (req.method === 'POST') {
      console.log('   Clé X-API-Key reçue : ' + (req.headers['x-api-key'] ? 'oui' : 'NON'));
      if (req.headers['x-api-key'] !== API_KEY) return send(res, 401, { erreur: 'Clé d\'API absente ou invalide (en-tête X-API-Key)' });
      let data = '';
      req.on('data', chunk => (data += chunk));
      req.on('end', () => {
        console.log('   Corps reçu : ' + data);
        let o;
        try { o = JSON.parse(data); } catch (e) { return send(res, 400, { erreur: 'JSON invalide' }); }
        const manquants = ['numeroCommande', 'machine', 'quantite'].filter(k => o[k] === undefined || o[k] === '');
        if (manquants.length) return send(res, 400, { erreur: 'Champs manquants : ' + manquants.join(', ') });
        const q = Number(o.quantite);
        if (!Number.isInteger(q) || q < 1 || q > 10000) return send(res, 422, { erreur: 'Quantité invalide (entier entre 1 et 10000)' });
        const m = machines[String(o.machine).toUpperCase()];
        if (!m) return send(res, 404, { erreur: 'Machine inconnue : ' + o.machine });
        if (m.statut === 'ARRET') return send(res, 409, { erreur: 'Machine à l\'arrêt : ordre refusé', machine: o.machine });
        const ordre = { idOrdre: 'OP-' + String(compteur++).padStart(4, '0'), statut: 'ACCEPTE', recuLe: new Date().toISOString(), ...o };
        ordres.push(ordre);
        console.log('Ordre reçu :', JSON.stringify(ordre));
        return send(res, 201, ordre);
      });
      return;
    }
  }
  if (req.method === 'GET' && url.pathname === '/') return send(res, 200, { service: 'Simulateur atelier MécaPrécision', ok: true });
  send(res, 404, { erreur: 'Route inconnue : ' + req.method + ' ' + url.pathname });
});
server.listen(PORT, () => console.log('Simulateur atelier sur http://localhost:' + PORT));
