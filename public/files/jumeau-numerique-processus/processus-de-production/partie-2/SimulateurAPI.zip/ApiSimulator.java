package mecaprecision;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/**
 * Simulateur d'API de l'atelier MécaPrécision (Partie II du TP), version Java.
 * Mêmes routes que api-simulator.js. Lancement : java -jar api-simulator.jar
 * GET  /api/machines/{id}/etat      GET /api/qualite/{categorie}
 * POST /api/ordres-production (en-tête X-API-Key)      GET /api/ordres-production
 */
public class ApiSimulator {
    static final String API_KEY = System.getenv("API_KEY") != null ? System.getenv("API_KEY") : "tp-mecaprecision-2026";
    static final Random RND = new Random();
    static final Map<String, double[]> MACHINES = new LinkedHashMap<>(); // temperature, vibration, cadence
    static final Map<String, String> STATUTS = new LinkedHashMap<>();
    static final Map<String, Double> DEFAUTS = new LinkedHashMap<>();
    static final List<String> ORDRES = new ArrayList<>();
    static int compteur = 1;

    static {
        MACHINES.put("M-01", new double[]{62, 2.1, 110}); STATUTS.put("M-01", "EN_MARCHE");
        MACHINES.put("M-02", new double[]{58, 1.8, 95});  STATUTS.put("M-02", "EN_MARCHE");
        MACHINES.put("M-03", new double[]{81, 4.6, 70});  STATUTS.put("M-03", "ALERTE");
        MACHINES.put("M-04", new double[]{24, 0.0, 0});   STATUTS.put("M-04", "ARRET");
        DEFAUTS.put("A", 0.8); DEFAUTS.put("B", 1.5); DEFAUTS.put("C", 2.7); DEFAUTS.put("D", 4.2);
    }

    static double noise(double v, double a) {
        return Math.round((v + (RND.nextDouble() * 2 - 1) * a) * 10) / 10.0;
    }
    static String num(double d) { return String.format(Locale.ROOT, "%s", d); }
    static String q(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            if (c == '"' || c == '\\') b.append('\\').append(c);
            else if (c == '\n') b.append("\\n");
            else if (c < 0x20) b.append(' ');
            else b.append(c);
        }
        return b.append('"').toString();
    }
    static void send(HttpExchange ex, int code, String json) throws IOException {
        byte[] b = json.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        ex.sendResponseHeaders(code, b.length);
        try (OutputStream os = ex.getResponseBody()) { os.write(b); }
    }
    static String err(String m) { return "{\"erreur\":" + q(m) + "}"; }

    /** Analyse minimale d'un objet JSON à plat : {"cle": valeur, ...}. */
    static Map<String, String> parseJson(String s) {
        Map<String, String> m = new LinkedHashMap<>();
        s = s.trim();
        if (!s.startsWith("{") || !s.endsWith("}")) throw new IllegalArgumentException();
        int i = 1, n = s.length() - 1;
        while (i < n) {
            while (i < n && (Character.isWhitespace(s.charAt(i)) || s.charAt(i) == ',')) i++;
            if (i >= n) break;
            if (s.charAt(i) != '"') throw new IllegalArgumentException();
            int[] p = {i};
            String k = readString(s, p);
            i = p[0];
            while (Character.isWhitespace(s.charAt(i))) i++;
            if (s.charAt(i) != ':') throw new IllegalArgumentException();
            i++;
            while (Character.isWhitespace(s.charAt(i))) i++;
            String v;
            if (s.charAt(i) == '"') { p[0] = i; v = readString(s, p); i = p[0]; }
            else {
                int j = i;
                while (j < n && s.charAt(j) != ',') j++;
                v = s.substring(i, j).trim(); i = j;
                if (v.startsWith("{") || v.startsWith("[")) throw new IllegalArgumentException();
            }
            m.put(k, v);
        }
        return m;
    }
    static String readString(String s, int[] p) {
        StringBuilder b = new StringBuilder();
        int i = p[0] + 1;
        while (s.charAt(i) != '"') {
            char c = s.charAt(i);
            if (c == '\\') {
                i++; char d = s.charAt(i);
                if (d == 'n') b.append('\n'); else if (d == 'u') { b.append((char) Integer.parseInt(s.substring(i + 1, i + 5), 16)); i += 4; } else b.append(d);
            } else b.append(c);
            i++;
        }
        p[0] = i + 1;
        return b.toString();
    }

    static void handle(HttpExchange ex) throws IOException {
        String method = ex.getRequestMethod();
        String path = ex.getRequestURI().getPath();
        String[] parts = path.replaceAll("^/+|/+$", "").split("/");
        if (method.equals("OPTIONS")) {
            ex.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            ex.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, X-API-Key");
            ex.getResponseHeaders().set("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
            ex.sendResponseHeaders(204, -1); ex.close(); return;
        }
        if (method.equals("GET") && parts.length == 4 && parts[0].equals("api") && parts[1].equals("machines") && parts[3].equals("etat")) {
            String id = parts[2].toUpperCase();
            double[] m = MACHINES.get(id);
            if (m == null) { send(ex, 404, err("Machine inconnue : " + id)); return; }
            String st = STATUTS.get(id);
            boolean actif = !st.equals("ARRET");
            send(ex, 200, "{\"machine\":" + q(id) + ",\"statut\":" + q(st)
                + ",\"temperature\":" + num(actif ? noise(m[0], 1.5) : m[0])
                + ",\"vibration\":" + num(actif ? noise(m[1], 0.2) : 0)
                + ",\"cadence\":" + (actif ? Math.round(noise(m[2], 3)) : 0)
                + ",\"horodatage\":" + q(Instant.now().toString()) + "}");
            return;
        }
        if (method.equals("GET") && parts.length == 3 && parts[0].equals("api") && parts[1].equals("qualite")) {
            String c = parts[2].toUpperCase();
            Double d = DEFAUTS.get(c);
            if (d == null) { send(ex, 404, err("Catégorie inconnue : " + c)); return; }
            send(ex, 200, "{\"categorie\":" + q(c) + ",\"tauxDefauts\":" + num(noise(d, 0.2)) + ",\"seuil\":3.0,\"horodatage\":" + q(Instant.now().toString()) + "}");
            return;
        }
        if (parts.length == 2 && parts[0].equals("api") && parts[1].equals("ordres-production")) {
            if (method.equals("GET")) { send(ex, 200, "[" + String.join(",", ORDRES) + "]"); return; }
            if (method.equals("POST")) {
                String key = ex.getRequestHeaders().getFirst("X-API-Key");
                System.out.println("   Clé X-API-Key reçue : " + (key != null ? "oui" : "NON"));
                if (key == null || !key.equals(API_KEY)) { send(ex, 401, err("Clé d'API absente ou invalide (en-tête X-API-Key)")); return; }
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                try (InputStream in = ex.getRequestBody()) { in.transferTo(bo); }
                System.out.println("   Corps reçu : " + bo.toString(StandardCharsets.UTF_8));
                Map<String, String> o;
                try { o = parseJson(bo.toString(StandardCharsets.UTF_8)); }
                catch (RuntimeException e) { send(ex, 400, err("JSON invalide")); return; }
                List<String> manquants = new ArrayList<>();
                for (String k : new String[]{"numeroCommande", "machine", "quantite"})
                    if (!o.containsKey(k) || o.get(k).isEmpty()) manquants.add(k);
                if (!manquants.isEmpty()) { send(ex, 400, err("Champs manquants : " + String.join(", ", manquants))); return; }
                int qte;
                try { qte = (int) Double.parseDouble(o.get("quantite")); if (qte != Double.parseDouble(o.get("quantite"))) throw new NumberFormatException(); }
                catch (NumberFormatException e) { send(ex, 422, err("Quantité invalide (entier entre 1 et 10000)")); return; }
                if (qte < 1 || qte > 10000) { send(ex, 422, err("Quantité invalide (entier entre 1 et 10000)")); return; }
                String mid = o.get("machine").toUpperCase();
                if (!MACHINES.containsKey(mid)) { send(ex, 404, err("Machine inconnue : " + o.get("machine"))); return; }
                if (STATUTS.get(mid).equals("ARRET")) { send(ex, 409, err("Machine à l'arrêt : ordre refusé")); return; }
                StringBuilder b = new StringBuilder("{\"idOrdre\":" + q(String.format("OP-%04d", compteur++)) + ",\"statut\":\"ACCEPTE\",\"recuLe\":" + q(Instant.now().toString()));
                for (Map.Entry<String, String> e : o.entrySet()) {
                    String v = e.getValue();
                    boolean nombre = v.matches("-?\\d+(\\.\\d+)?");
                    b.append(",").append(q(e.getKey())).append(":").append(nombre ? v : q(v));
                }
                b.append("}");
                ORDRES.add(b.toString());
                System.out.println("Ordre reçu : " + b);
                send(ex, 201, b.toString());
                return;
            }
        }
        if (method.equals("GET") && path.equals("/")) { send(ex, 200, "{\"service\":\"Simulateur atelier MécaPrécision\",\"ok\":true}"); return; }
        send(ex, 404, err("Route inconnue : " + method + " " + path));
    }

    public static void main(String[] args) throws IOException {
        int port = System.getenv("PORT") != null ? Integer.parseInt(System.getenv("PORT")) : 3000;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/", ex -> {
            try { handle(ex); System.out.println(java.time.LocalTime.now().withNano(0) + "  " + ex.getRequestMethod() + " " + ex.getRequestURI() + "  ->  " + ex.getResponseCode()); }
            catch (Exception e) { try { send(ex, 500, err("Erreur interne")); } catch (IOException ignored) { } }
        });
        server.start();
        System.out.println("Simulateur atelier sur http://localhost:" + port);
    }
}
